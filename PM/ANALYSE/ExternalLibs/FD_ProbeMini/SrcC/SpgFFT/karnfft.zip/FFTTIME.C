#include <stdio.h>
#include "fft.h"

complex x[256];

main(argc,argv)
int argc;
char *argv[];
{
	int i;

	fftinit();
	for(i=0;i<100000;i++){
		fft256(x);
	}
}
