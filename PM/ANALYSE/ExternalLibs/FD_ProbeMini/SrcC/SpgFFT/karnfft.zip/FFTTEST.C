#include <stdio.h>
#include <math.h>
#include "fft.h"
complex x[256];
main()
{
	int i;


	fftinit();
	printf("init done\n");

	for(i=0;i<256;i++){
		x[i].re = cos(12*M_PI*i/256);
		x[i].im = 0;
	}
	fft256(x);
	fftswap(x,256);
	for(i=0;i<256;i++)
		printf("%d: %f %f\n",i,x[i].re,x[i].im);
}

